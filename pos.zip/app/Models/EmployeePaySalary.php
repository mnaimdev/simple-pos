<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmployeePaySalary extends Model
{
    use HasFactory;

    protected $guarded = ['id'];


    function rel_to_employee()
    {
        return $this->belongsTo(Employee::class, 'employee_id', 'id');
    }
}
