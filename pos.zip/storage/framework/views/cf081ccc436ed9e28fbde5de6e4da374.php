<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/dashboard_assets/css/attend.css')); ?>">
    <style>
        .switch-toggle {
            width: auto;
        }

        .switch-toggle label:not(.disabled) {
            cursor: pointer;
        }

        .switch-candy a {
            border: 1px solid #333;
            border-radius: 3px;
            background-color: white;
            background-image: -webkit-linear-gradient(top, rgba(255, 255, 255, 0.2), transparent);
            background-image: linear-gradient(to bottom, rgba(255, 255, 255, 0.2), transparent);
        }

        .switch-toggle.switch-candy,
        .switch-light.switch-candy>span {
            background-color: #5a6268;
            border-radius: 3px;
            box-shadow: inset 0 2px 6px rgba(0, 0, 0, 0.3), 0 1px 0 rgba(255, 255, 255, 0.2);
        }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <!-- Start Content-->


    <div class="container">
        <nav aria-label="breadcrumb"
            style="margin-top: 30px; display: flex; justify-content: space-between; align-items: center;">
            <a href="<?php echo e(route('attendence')); ?>" class="btn btn-info">List</a>

            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('attendence')); ?>">Attendece</a></li>
                <li class="breadcrumb-item"><a>Create</a></li>
            </ol>
        </nav>
    </div>



    <div class="container-fluid">

        <!-- end page title -->
        <div class="row">
            <div class="col-12">
                <div class="card">




                    <div class="card-body">
                        <form action="<?php echo e(route('attendence.store')); ?>" method="post" id="myForm">
                            <?php echo csrf_field(); ?>
                            <div class="form-group col-md-4">
                                <label for="date" class="control-label">Attendance Date</label>
                                <input type="date" name="date" id="date"
                                    class="checkdate form-control form-control-sm singledatepicker"
                                    placeholder="Attendance Date" autocomplete="off">
                                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger">
                                        <?php echo e($message); ?>

                                    </strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <table class="table sm table-bordered table-striped dt-responsive" style="width: 100%">
                                <thead>
                                    <tr>
                                        <th rowspan="2" class="text-center" style="vertical-align: middle">Sl.</th>
                                        <th rowspan="2" class="text-center" style="vertical-align: middle">Employee
                                            Name</th>
                                        <th colspan="3" class="text-center" style="vertical-align: middle">Attendance
                                            Status</th>
                                    </tr>
                                    <tr>
                                        <th class="text-center btn present_all"
                                            style="display: table-cell;background-color:#114190">Present</th>
                                        <th class="text-center btn leave_all"
                                            style="display: table-cell;background-color:#114190">Leave</th>
                                        <th class="text-center btn absent_all"
                                            style="display: table-cell;background-color:#114190">Absent</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="div <?php echo e($employee->id); ?>" class="text-center">
                                            <input type="hidden" name="employee_id[]" value="<?php echo e($employee->id); ?>"
                                                class="employee_id">
                                            <td><?php echo e($key + 1); ?></td>
                                            <td><?php echo e($employee->name); ?></td>
                                            <td colspan="3">
                                                <div class="switch-toggle switch-3 switch-candy">
                                                    <input class="present" id="present<?php echo e($key); ?>"
                                                        name="status<?php echo e($key); ?>" value="present" type="radio"
                                                        checked="checked">

                                                    <label for="present<?php echo e($key); ?>">Present</label>
                                                    <input class="leave" id="leave<?php echo e($key); ?>"
                                                        name="status<?php echo e($key); ?>" value="Leave" type="radio">

                                                    <label for="leave<?php echo e($key); ?>">Leave</label>
                                                    <input class="absent" id="absent<?php echo e($key); ?>"
                                                        name="status<?php echo e($key); ?>" value="Absent" type="radio">

                                                    <label for="absent<?php echo e($key); ?>">Absent</label>
                                                    <a></a>
                                                </div>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <button type="submit" class="btn btn-success btn-sm"> Submit </button>
                        </form>
                    </div>
                    <!-- end card body-->

                </div>
                <!-- end card -->
            </div>
            <!-- end col-->
        </div>
        <!-- end row-->
    </div>
    <!-- container -->


    <script type="text/javascript">
        $(document).on('click', '.present', function() {
            $(this).parents('tr').find('.datetime').css('pointer-events', 'none').css('background-color', '#dee2e6')
                .css('color', '#495057');
        });
        $(document).on('click', '.leave', function() {
            $(this).parents('tr').find('.datetime').css('pointer-events', '').css('background-color', 'white').css(
                'color', '#495057');
        });
        $(document).on('click', '.absent', function() {
            $(this).parents('tr').find('.datetime').css('pointer-events', 'none').css('background-color', '#dee2e6')
                .css('color', '#dee2e6');
        });
    </script>
    <script type="text/javascript">
        $(document).on('click', '.present_all', function() {
            $("input[value=Present]").prop('checked', true);
            $('.datetime').css('ponter-events', 'none').css('background-color', '#dee2e6').css('color', '#495057');
        });
        $(document).on('click', '.leave_all', function() {
            $("input[value=Leave]").prop('checked', true);
            $('.datetime').css('ponter-events', '').css('background-color', 'white').css('color', '#495057');
        });
        $(document).on('click', '.absent_all', function() {
            $("input[value=Absent]").prop('checked', true);
            $('.datetime').css('ponter-events', 'none').css('background-color', '#dee2e6').css('color', '#dee2e6');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\Personal Project\pos\resources\views/backend/attendence/create.blade.php ENDPATH**/ ?>