<?php $__env->startSection('content'); ?>
    <div class="container">
        <nav aria-label="breadcrumb"
            style="margin-top: 30px; display: flex; justify-content: space-between; align-items: center;">
            <div>
                <a href="<?php echo e(route('assign.role')); ?>" class="btn btn-primary">Assign Role</a>
            </div>

            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a>Admin</a></li>
            </ol>
        </nav>
    </div>

    <div class="container my-2">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h3>Admin List</h3>
                    </div>

                    <div class="card-body">
                        <table class="table table-striped" id="table_id">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Image</th>
                                    <th>Role</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sl + 1); ?></td>
                                        <td><?php echo e($user->name); ?></td>

                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->phone == '' ? 'No Number' : $user->phone); ?></td>
                                        <td>
                                            <?php if($user->photo == ''): ?>
                                                <img width="32" src="<?php echo e(Avatar::create($user->name)->toBase64()); ?>">
                                            <?php else: ?>
                                                <img width="50" height="50"
                                                    src="<?php echo e(asset('/uploads/user')); ?>/<?php echo e($user->photo); ?>" alt="">
                                            <?php endif; ?>

                                        </td>
                                        <td>

                                            <?php $__empty_1 = true; $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <span class="badge badge-primary">
                                                    <?php echo e($role->name); ?>

                                                </span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <span>No Role</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('edit.assign.role', $user->id)); ?>"
                                                class="btn btn-primary">Edit</a>

                                            <a data-delete="<?php echo e(route('delete.assign.role', $user->id)); ?>"
                                                class="btn btn-danger delete">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\pos\resources\views/backend/admin.blade.php ENDPATH**/ ?>