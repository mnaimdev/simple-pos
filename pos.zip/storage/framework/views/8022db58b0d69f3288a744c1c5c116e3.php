<img src="<?php echo e(asset('logo.png')); ?>" width="100" alt="">
<?php /**PATH D:\Working Directory\Laravel\Personal Project\pos\resources\views/components/application-logo.blade.php ENDPATH**/ ?>