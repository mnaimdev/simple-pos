<?php $__env->startSection('content'); ?>
    <div class="container">
        <nav aria-label="breadcrumb"
            style="margin-top: 30px; display: flex; justify-content: space-between; align-items: center;">
            <a href="<?php echo e(route('product')); ?>" class="btn btn-info">List</a>

            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('product')); ?>">Product</a></li>
                <li class="breadcrumb-item"><a>Barcode</a></li>
            </ol>
        </nav>
    </div>

    <div class="container my-2">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h3>Product Barcode</h3>
                    </div>


                    <?php
                        $generator = new Picqer\Barcode\BarcodeGeneratorHTML();
                    ?>



                    <div class="card-body">

                        <table class="table table-striped">
                            <tr>
                                <th>Product Name</th>
                                <th>BarCode</th>
                            </tr>
                            <tr>
                                <td><?php echo e($product->product_name); ?></td>
                                <td>
                                    <?php echo $generator->getBarcode($product->product_code, $generator::TYPE_CODE_128); ?>

                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\Personal Project\pos\resources\views/backend/product/barcode.blade.php ENDPATH**/ ?>