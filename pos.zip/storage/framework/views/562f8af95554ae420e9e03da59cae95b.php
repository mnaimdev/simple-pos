<?php $__env->startSection('content'); ?>
    <div class="container mt-3">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h3>Order Info</h3>
                    </div>
                    <div class="card-body">

                        <form action="<?php echo e(route('order.status.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <ul class="list-group">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <li class="list-group-item">Customer Name: <?php echo e($order->rel_to_customer->name); ?></li>
                                        <li class="list-group-item">Customer Email: <?php echo e($order->rel_to_customer->email); ?>

                                        </li>
                                        <li class="list-group-item">Order Date: <?php echo e($order->order_date); ?></li>
                                        <li class="list-group-item">Payment Method: <?php echo e($order->payment_method); ?></li>
                                        <li class="list-group-item">Due: <?php echo e($order->due); ?> TK</li>

                                    </div>
                                    <div class="col-lg-6">
                                        <li class="list-group-item">Subtotal: <?php echo e($order->sub_total); ?> TK</li>
                                        <li class="list-group-item">Vat: <?php echo e($order->vat); ?> TK</li>
                                        <li class="list-group-item">Total: <?php echo e($order->total); ?> TK</li>
                                        <li class="list-group-item">Pay: <?php echo e($order->pay); ?> TK</li>
                                        <li class="list-group-item">Order Status: <span
                                                class="badge badge-danger"><?php echo e($order->order_status); ?></span></li>

                                    </div>

                                    <input type="hidden" name="id" value="<?php echo e($order->id); ?>">

                            </ul>
                            <button class="btn btn-primary mt-3" type="submit">Complete Order</button>
                        </form>
                    </div>
                </div>
            </div>


            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h3>Order Details</h3>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <tr>
                                <th>SL</th>
                                <th>Product Name</th>
                                <th>Product Image</th>
                                <th>Quantity</th>
                            </tr>
                            <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($sl + 1); ?></td>
                                    <td><?php echo e($order->rel_to_product->product_name); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset('/uploads/product')); ?>/<?php echo e($order->rel_to_product->product_image); ?>"
                                            width="50" height="50">
                                    </td>
                                    <td><?php echo e($order->quantity); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\pos\resources\views/backend/pos/order_details.blade.php ENDPATH**/ ?>