<?php $__env->startSection('content'); ?>
    <div class="container">
        <nav aria-label="breadcrumb"
            style="margin-top: 30px; display: flex; justify-content: space-between; align-items: center;">
            <a href=""></a>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a>Pay Salary</a></li>
            </ol>
        </nav>
    </div>

    <div class="container my-2">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h3>Pay Salary List</h3>
                    </div>

                    <div class="card-body">
                        <table class="table table-striped" id="table_id">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Name</th>
                                    <th>Month</th>
                                    <th>Salary</th>
                                    <th>Advance Salary</th>
                                    <th>Due Amount</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sl + 1); ?></td>
                                        <td><?php echo e($employee->name); ?></td>

                                        <td><?php echo e(date('F', strtotime('-1 month'))); ?></td>
                                        <td><?php echo e($employee->salary); ?></td>
                                        <td>

                                            <?php
                                                $advanceSalary = App\Models\EmployeeAdvanceSalary::where('employee_id', $employee->id)
                                                    ->where('year', Carbon\Carbon::now()->year)
                                                    ->first();
                                            ?>




                                            <?php if(!empty($advanceSalary->amount)): ?>
                                                <span><?php echo e($advanceSalary->amount); ?></span>
                                            <?php else: ?>
                                                <span>No Advance</span>
                                            <?php endif; ?>
                                        </td>

                                        <td>

                                            <?php if(!empty($advanceSalary->amount)): ?>
                                                <?php
                                                    $salary = $employee->salary;
                                                    $due = $salary - $advanceSalary->amount;
                                                ?>
                                                <?php echo e($due); ?>

                                            <?php else: ?>
                                                <?php
                                                    $due = $employee->salary;
                                                ?>
                                                <?php echo e($due); ?>

                                            <?php endif; ?>


                                        </td>
                                        <td>


                                            <?php
                                                $status = App\Models\EmployeePaySalary::where('employee_id', $employee->id)->exists();
                                            ?>

                                            <?php if(!empty($status)): ?>
                                                <div class="badge badge-primary">paid</div>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('pay.now', $employee->id)); ?>" class="btn btn-primary">Pay
                                                    Now</a>
                                            <?php endif; ?>

                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer_scripts'); ?>
    <script>
        $('.delete').click(function() {
            Swal.fire({
                title: 'Are you sure?',
                text: "Delete this record?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    var link = $(this).attr('data-delete');
                    location.href = link;
                }
            })
        });
    </script>

    <script>
        $(document).ready(function() {
            $('#table_id').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\Personal Project\pos\resources\views/backend/employee/pay/index.blade.php ENDPATH**/ ?>