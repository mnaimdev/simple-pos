<img src="{{ asset('logo.png') }}" width="100" alt="">
