<?php $__env->startSection('content'); ?>
    <div class="container">
        <nav aria-label="breadcrumb"
            style="margin-top: 30px; display: flex; justify-content: space-between; align-items: center;">
            <div>
                <a href="<?php echo e(route('product.create')); ?>" class="btn btn-primary">Add New</a>
                &nbsp;&nbsp;
                <a href="<?php echo e(route('product.import')); ?>" class="btn btn-info">Import</a>
                &nbsp;&nbsp;
                <a href="<?php echo e(route('product.export')); ?>" class="btn btn-danger">Export</a>
            </div>

            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a>Product</a></li>
            </ol>
        </nav>
    </div>

    <div class="container my-2">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h3>Product List</h3>
                    </div>

                    <div class="card-body">
                        <table class="table table-striped" id="table_id">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Product Name</th>
                                    <th>Category</th>
                                    <th>Product Image</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sl + 1); ?></td>
                                        <td><?php echo e($product->product_name); ?></td>

                                        <td><?php echo e($product->rel_to_category->category_name); ?></td>
                                        <td>
                                            <img width="50" height="50"
                                                src="<?php echo e(asset('/uploads/product')); ?>/<?php echo e($product->product_image); ?>"
                                                alt="">
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('product.barcode', $product->id)); ?>" class="btn btn-info">Bar
                                                Code</a>

                                            <a href="<?php echo e(route('product.edit', $product->id)); ?>"
                                                class="btn btn-primary">Edit</a>

                                            <a href="<?php echo e(route('product.inventory', $product->id)); ?>"
                                                class="btn btn-primary">Inventory</a>

                                            <a data-delete="<?php echo e(route('product.delete', $product->id)); ?>"
                                                class="btn btn-danger delete">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\Personal Project\pos\resources\views/backend/product/index.blade.php ENDPATH**/ ?>