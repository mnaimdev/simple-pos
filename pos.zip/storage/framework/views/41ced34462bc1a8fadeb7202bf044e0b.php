<?php $__env->startSection('content'); ?>
    <div class="container">
        <nav aria-label="breadcrumb"
            style="margin-top: 30px; display: flex; justify-content: space-between; align-items: center;">
            <a href="<?php echo e(route('pay.salary')); ?>" class="btn btn-primary">List</a>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('pay.salary')); ?>">Monthly Salary</a></li>
                <li class="breadcrumb-item"><a>Paid</a></li>
            </ol>
        </nav>
    </div>

    <div class="container my-2">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h3>Monthly Salary</h3>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <tr>
                                <th>SL</th>
                                <th>Name</th>
                                <th>Month</th>
                                <th>Amount</th>
                                <th>Status</th>
                            </tr>
                            <?php $__currentLoopData = $month_salaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($sl + 1); ?></td>
                                    <td><?php echo e($salary->rel_to_employee->name); ?></td>
                                    <td><?php echo e($salary->month); ?></td>
                                    <td><?php echo e($salary->paid_amount); ?></td>
                                    <td>
                                        <span class="badge badge-primary">Paid</span>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\Personal Project\pos\resources\views/backend/employee/pay/month_salary.blade.php ENDPATH**/ ?>