<?php $__env->startSection('content'); ?>
    <div class="container">
        <nav aria-label="breadcrumb"
            style="margin-top: 30px; display: flex; justify-content: space-between; align-items: center;">
            <a href="<?php echo e(route('employee')); ?>" class="btn btn-info">List</a>

            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('employee')); ?>">Employee</a></li>
                <li class="breadcrumb-item"><a>Show</a></li>
            </ol>
        </nav>
    </div>

    <div class="container my-2">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <ul class="list-group">
                            <li class="list-group-item"><b>Name : </b> <?php echo e($employee_info->name); ?></li>
                            <li class="list-group-item"><b>Email : </b> <?php echo e($employee_info->email); ?></li>
                            <li class="list-group-item"><b>Phone : </b> <?php echo e($employee_info->phone); ?></li>
                            <li class="list-group-item"><b>Address : </b> <?php echo e($employee_info->address); ?></li>
                            <li class="list-group-item"><b>Country : </b> <?php echo e($employee_info->country); ?></li>
                            <li class="list-group-item"><b>City : </b> <?php echo e($employee_info->city); ?></li>
                            <li class="list-group-item"><b>Salary : </b> <?php echo e($employee_info->salary); ?></li>
                            <li class="list-group-item"><b>Experience : </b> <?php echo e($employee_info->experience); ?></li>
                            <li class="list-group-item"><b>Vacation : </b> <?php echo e($employee_info->vacation); ?></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\Personal Project\pos\resources\views/backend/employee/view.blade.php ENDPATH**/ ?>