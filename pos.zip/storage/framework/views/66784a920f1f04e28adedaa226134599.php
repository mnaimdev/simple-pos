<?php $__env->startSection('content'); ?>
    <div class="container">
        <nav aria-label="breadcrumb"
            style="margin-top: 30px; display: flex; justify-content: space-between; align-items: center;">
            <div>

            </div>

            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a>Complete Order</a></li>
            </ol>
        </nav>
    </div>

    <div class="container my-2">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h3>Complete Order List</h3>
                    </div>

                    <div class="card-body">
                        <table class="table table-striped" id="table_id">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Order Id</th>
                                    <th>Date</th>
                                    <th>Payment Method</th>
                                    <th>Customer</th>
                                    <th>Order Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sl + 1); ?></td>
                                        <td><?php echo e($order->order_id); ?></td>
                                        <td><?php echo e($order->order_date); ?></td>
                                        <td><?php echo e($order->payment_method); ?></td>
                                        <td><?php echo e($order->rel_to_customer->name); ?></td>
                                        <td class="badge badge-danger mt-2"><?php echo e($order->order_status); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('invoice.download', $order->id)); ?>"
                                                class="btn btn-primary">Invoice PDF</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Working Directory\Laravel\pos\resources\views/backend/pos/complete.blade.php ENDPATH**/ ?>