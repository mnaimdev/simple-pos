<footer class="footer text-right ml-5">
    2023 © <a href="https://www.mnaimdev.com">Mohammad Naim</a> - all rights reserved
</footer>
<?php /**PATH D:\Working Directory\Laravel\pos\resources\views/body/footer.blade.php ENDPATH**/ ?>